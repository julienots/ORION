import 'package:speech_to_text/speech_to_text.dart' as stt;
import '../config/app_config.dart';

/// Détecte en continu le mot "ORION" (même app fermée, via le service
/// d'arrière-plan démarré dans main.dart / background_task.dart) et
/// déclenche [onWakeWordDetected].
///
/// Utilise la reconnaissance vocale du téléphone (speech_to_text, déjà
/// utilisée ailleurs dans l'app) au lieu de Picovoice : aucun compte, clé ou
/// modèle à télécharger — ça marche directement après installation. Le
/// moteur de reconnaissance d'Android ne permet pas une écoute strictement
/// infinie d'un coup : on tourne donc par sessions courtes redémarrées en
/// boucle tant que [start] n'a pas été suivi de [stop].
class WakeWordService {
  final stt.SpeechToText _speech = stt.SpeechToText();
  Function()? _onDetected;
  bool _enabled = false; // écoute du mot de réveil activée par l'utilisateur
  bool _paused = false; // en pause pendant qu'une conversation est en cours
  bool _restarting = false;

  Future<void> start({required Function() onWakeWordDetected}) async {
    _onDetected = onWakeWordDetected;
    _enabled = true;
    _paused = false;

    final available = await _speech.initialize(
      onStatus: _onStatus,
      onError: (error) => _scheduleRestart(),
    );
    if (!available) {
      throw Exception(
        "Reconnaissance vocale indisponible sur cet appareil (vérifie que "
        "l'app Google est installée et à jour).",
      );
    }
    await _listenCycle();
  }

  void _onStatus(String status) {
    if (!_enabled || _paused) return;
    // 'done' / 'notListening' = la session s'est terminée (silence, timeout
    // du moteur...) : on en relance une nouvelle tout de suite.
    if (status == 'done' || status == 'notListening') {
      _scheduleRestart();
    }
  }

  void _scheduleRestart() {
    if (!_enabled || _paused || _restarting) return;
    _restarting = true;
    Future.delayed(const Duration(milliseconds: 400), () {
      _restarting = false;
      if (_enabled && !_paused) _listenCycle();
    });
  }

  Future<void> _listenCycle() async {
    if (!_enabled || _paused) return;
    try {
      await _speech.listen(
        localeId: 'fr_FR',
        listenFor: const Duration(seconds: 55),
        pauseFor: const Duration(seconds: 8),
        partialResults: true,
        onResult: (result) {
          final heard = result.recognizedWords.toLowerCase();
          if (heard.contains(AppConfig.wakeWord)) {
            _handleDetected();
          }
        },
      );
    } catch (_) {
      _scheduleRestart();
    }
  }

  Future<void> _handleDetected() async {
    if (_paused) return;
    // On coupe cette session tout de suite : c'est le premier plan (voir
    // home_screen.dart) qui va ouvrir sa propre écoute pour la commande, pas
    // question que les deux se disputent le micro en même temps.
    await _speech.stop();
    _onDetected?.call();
  }

  /// Suspend l'écoute du mot de réveil, typiquement pendant qu'une
  /// conversation est en cours au premier plan.
  Future<void> pause() async {
    _paused = true;
    await _speech.stop();
  }

  /// Relance l'écoute du mot de réveil après une conversation.
  Future<void> resume() async {
    if (!_enabled) return;
    _paused = false;
    await _listenCycle();
  }

  Future<void> stop() async {
    _enabled = false;
    _paused = false;
    await _speech.stop();
  }
}
