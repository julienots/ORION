import 'package:porcupine_flutter/porcupine_manager.dart';
import 'package:porcupine_flutter/porcupine_error.dart';
import '../config/app_config.dart';

/// Détecte en continu le mot "ORION" (même app fermée, via le service
/// d'arrière-plan démarré dans main.dart / background_task.dart) et
/// déclenche [onWakeWordDetected].
///
/// ⚠️ Étape obligatoire avant que ça fonctionne :
/// 1. Crée un compte gratuit sur https://console.picovoice.ai/
/// 2. Va dans "Porcupine" > crée un mot-clé personnalisé "Orion" (plateforme Android)
/// 3. Télécharge le fichier .ppn généré
/// 4. Place-le dans android/app/src/main/assets/orion_android.ppn
/// 5. Récupère ta clé "AccessKey" et mets-la dans les Réglages de l'app
class WakeWordService {
  PorcupineManager? _manager;

  Future<void> start({
    required String accessKey,
    required Function() onWakeWordDetected,
  }) async {
    if (accessKey.isEmpty) {
      throw Exception('Clé Picovoice manquante (voir Réglages > IA).');
    }
    try {
      _manager = await PorcupineManager.fromKeywordPaths(
        accessKey,
        [AppConfig.wakeWordAssetPath],
        (keywordIndex) => onWakeWordDetected(),
        sensitivities: [0.6],
      );
      await _manager?.start();
    } on PorcupineException catch (e) {
      throw Exception('Erreur Porcupine : ${e.message}');
    }
  }

  Future<void> stop() async {
    await _manager?.stop();
    await _manager?.delete();
    _manager = null;
  }
}
