import 'dart:async';
import 'dart:convert';
import 'package:flutter_overlay_window/flutter_overlay_window.dart';

/// Type de carte (choisit l'icône/couleur côté widget flottant).
enum OrionOverlayType { info, thinking, action, success, error }

class _Notice {
  final int id;
  final String message;
  final OrionOverlayType type;
  Timer? timer;
  _Notice({required this.id, required this.message, required this.type});

  Map<String, dynamic> toJson() => {'id': id, 'message': message, 'type': type.name};
}

/// Pilote la petite fenêtre flottante système qui affiche les cartes de
/// statut d'ORION PAR-DESSUS les autres apps (pas seulement à l'intérieur
/// d'ORION). Nécessite la permission Android "Afficher par-dessus les
/// autres apps" (voir SettingsScreen : hasPermission()/requestPermission()).
///
/// Toute la logique (liste des cartes, minuteries d'auto-fermeture) vit ici,
/// dans l'app principale : la fenêtre flottante (voir
/// widgets/orion_floating_overlay.dart, moteur Flutter séparé) ne fait
/// qu'afficher ce qu'on lui envoie via shareData, et nous prévient par le
/// même canal quand l'utilisateur ferme une carte lui-même.
class SystemOverlayService {
  SystemOverlayService._();
  static final SystemOverlayService instance = SystemOverlayService._();

  final List<_Notice> _notices = [];
  bool _isShowing = false;
  bool _listenerReady = false;
  int _nextId = 0;

  Future<bool> hasPermission() => FlutterOverlayWindow.isPermissionGranted();

  /// Ouvre l'écran système pour accorder la permission. Se termine une fois
  /// la permission accordée (ou refusée).
  Future<bool> requestPermission() async =>
      (await FlutterOverlayWindow.requestPermission()) ?? false;

  void _ensureListener() {
    if (_listenerReady) return;
    _listenerReady = true;
    FlutterOverlayWindow.overlayListener.listen((event) {
      try {
        final data = event is String ? jsonDecode(event) : event;
        if (data is Map && data['action'] == 'dismiss' && data['id'] is int) {
          _remove(data['id'] as int);
        }
      } catch (_) {
        // message inattendu : on l'ignore plutôt que de planter.
      }
    });
  }

  Future<void> _sync() {
    return FlutterOverlayWindow.shareData(
      jsonEncode({'notices': _notices.map((n) => n.toJson()).toList()}),
    );
  }

  void _remove(int id) {
    final idx = _notices.indexWhere((n) => n.id == id);
    if (idx == -1) return;
    _notices[idx].timer?.cancel();
    _notices.removeAt(idx);
    if (_notices.isEmpty) {
      _isShowing = false;
      FlutterOverlayWindow.closeOverlay();
    } else {
      _sync();
    }
  }

  /// Empile une nouvelle carte par-dessus les autres apps (garde les
  /// précédentes, 3 maximum affichées à la fois). Ne fait rien si la
  /// permission n'a pas été accordée.
  Future<void> show(
    String message, {
    OrionOverlayType type = OrionOverlayType.info,
    bool autoDismiss = true,
    Duration duration = const Duration(seconds: 4),
  }) async {
    if (!await hasPermission()) return;
    _ensureListener();

    if (!_isShowing) {
      await FlutterOverlayWindow.showOverlay(
        height: 260,
        width: WindowSize.matchParent,
        alignment: OverlayAlignment.topCenter,
        flag: OverlayFlag.defaultFlag,
        overlayTitle: 'ORION',
        overlayContent: 'Affiche des infos par-dessus vos apps',
        enableDrag: false,
      );
      _isShowing = true;
      // Laisse le temps au moteur Flutter de la fenêtre flottante de démarrer
      // avant de lui envoyer la première carte.
      await Future.delayed(const Duration(milliseconds: 300));
    }

    final id = _nextId++;
    final notice = _Notice(id: id, message: message, type: type);
    _notices.add(notice);
    while (_notices.length > 3) {
      _notices.removeAt(0).timer?.cancel();
    }
    if (autoDismiss) {
      notice.timer = Timer(duration, () => _remove(id));
    }
    await _sync();
  }

  /// Remplace la dernière carte au lieu d'en empiler une nouvelle — pratique
  /// pour faire évoluer un même statut ("j'écoute" -> "je réfléchis" -> "fait").
  Future<void> update(
    String message, {
    OrionOverlayType type = OrionOverlayType.info,
    bool autoDismiss = true,
    Duration duration = const Duration(seconds: 4),
  }) async {
    if (_notices.isNotEmpty) {
      _notices.removeLast().timer?.cancel();
    }
    await show(message, type: type, autoDismiss: autoDismiss, duration: duration);
  }

  /// Ferme toutes les cartes et la fenêtre flottante.
  Future<void> clear() async {
    for (final n in _notices) {
      n.timer?.cancel();
    }
    _notices.clear();
    if (_isShowing) {
      _isShowing = false;
      await FlutterOverlayWindow.closeOverlay();
    }
  }
}
