import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import '../config/app_config.dart';

/// Gère la communication avec le cerveau IA d'ORION.
/// Trois fournisseurs possibles (choix stocké dans Réglages, clé
/// 'ai_provider' : 'groq' | 'mistral' | 'gemini') : Groq et Mistral utilisent
/// une API compatible OpenAI (même format de requête) ; Gemini a son propre
/// format et est géré à part dans _askGemini.
class AiService {
  static const _endpointGroq = 'https://api.groq.com/openai/v1/chat/completions';
  static const _endpointMistral = 'https://api.mistral.ai/v1/chat/completions';
  static const _endpointGeminiBase =
      'https://generativelanguage.googleapis.com/v1beta/models';

  Future<String> _getProvider() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('ai_provider') ?? 'groq';
  }

  Future<String> _getKey(String provider) async {
    final prefs = await SharedPreferences.getInstance();
    switch (provider) {
      case 'mistral':
        if (AppConfig.mistralApiKey.isNotEmpty) return AppConfig.mistralApiKey;
        return prefs.getString('mistral_api_key') ?? '';
      case 'gemini':
        if (AppConfig.geminiApiKey.isNotEmpty) return AppConfig.geminiApiKey;
        return prefs.getString('gemini_api_key') ?? '';
      case 'groq':
      default:
        if (AppConfig.groqApiKey.isNotEmpty) return AppConfig.groqApiKey;
        return prefs.getString('groq_api_key') ?? '';
    }
  }

  /// Envoie une question à ORION et retourne la réponse texte complète.
  Future<String> ask(String userMessage, {List<Map<String, String>>? history}) async {
    final provider = await _getProvider();
    final key = await _getKey(provider);
    if (key.isEmpty) {
      final label = provider == 'mistral' ? 'Mistral' : provider == 'gemini' ? 'Gemini' : 'Groq';
      return "Je n'ai pas encore de clé $label. Ajoute-la dans Réglages d'ORION.";
    }

    try {
      switch (provider) {
        case 'mistral':
          return await _askOpenAiCompatible(
              _endpointMistral, AppConfig.mistralModel, key, userMessage, history);
        case 'gemini':
          return await _askGemini(key, userMessage, history);
        case 'groq':
        default:
          return await _askOpenAiCompatible(
              _endpointGroq, AppConfig.groqModel, key, userMessage, history);
      }
    } catch (e) {
      return "Je n'arrive pas à contacter le serveur. Vérifie ta connexion. ($e)";
    }
  }

  /// Groq et Mistral exposent tous les deux une API "chat/completions"
  /// compatible OpenAI : même requête, seuls l'URL/le modèle/la clé changent.
  Future<String> _askOpenAiCompatible(String endpoint, String model, String key,
      String userMessage, List<Map<String, String>>? history) async {
    final messages = [
      {'role': 'system', 'content': AppConfig.orionSystemPrompt},
      ...?history,
      {'role': 'user', 'content': userMessage},
    ];

    final response = await http.post(
      Uri.parse(endpoint),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $key',
      },
      body: jsonEncode({
        'model': model,
        'messages': messages,
        'temperature': 0.6,
        'max_tokens': 500,
      }),
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(utf8.decode(response.bodyBytes));
      return data['choices'][0]['message']['content'] as String;
    }
    return "Erreur ORION (${response.statusCode}) : ${response.body}";
  }

  /// Gemini a un format différent : "contents" (rôles user/model) au lieu de
  /// "messages", et le prompt système passe par "systemInstruction".
  Future<String> _askGemini(
      String key, String userMessage, List<Map<String, String>>? history) async {
    final contents = <Map<String, dynamic>>[];
    for (final turn in history ?? const <Map<String, String>>[]) {
      final role = turn['role'] == 'assistant' ? 'model' : 'user';
      contents.add({
        'role': role,
        'parts': [
          {'text': turn['content'] ?? ''}
        ],
      });
    }
    contents.add({
      'role': 'user',
      'parts': [
        {'text': userMessage}
      ],
    });

    final uri = Uri.parse('$_endpointGeminiBase/${AppConfig.geminiModel}:generateContent');
    final response = await http.post(
      uri,
      headers: {
        'Content-Type': 'application/json',
        'x-goog-api-key': key,
      },
      body: jsonEncode({
        'contents': contents,
        'systemInstruction': {
          'parts': [
            {'text': AppConfig.orionSystemPrompt}
          ],
        },
        'generationConfig': {'temperature': 0.6, 'maxOutputTokens': 500},
      }),
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(utf8.decode(response.bodyBytes));
      final parts = data['candidates'][0]['content']['parts'] as List;
      return parts.map((p) => (p['text'] ?? '').toString()).join().trim();
    }
    return "Erreur ORION (${response.statusCode}) : ${response.body}";
  }
}

/// Tag technique que le prompt système demande à l'IA d'ajouter quand elle
/// détecte une vraie action à effectuer, ex : "[[ACTION:OPEN_APP:chrome]]".
/// Jamais lu à voix haute : on l'extrait ici avant de parler/afficher.
final RegExp _actionTag = RegExp(r'\[\[ACTION:([A-Z_]+):(.*?)\]\]', dotAll: true);

/// Résultat du découpage d'une réponse d'ORION : le texte à dire/afficher,
/// et l'action éventuelle à exécuter réellement sur le téléphone.
class ParsedResponse {
  final String spokenText;
  final String? actionType;
  final String? actionParam;
  const ParsedResponse(this.spokenText, this.actionType, this.actionParam);
}

ParsedResponse parseOrionResponse(String raw) {
  final match = _actionTag.firstMatch(raw);
  if (match == null) return ParsedResponse(raw.trim(), null, null);
  final clean = raw.replaceAll(_actionTag, '').trim();
  return ParsedResponse(
    clean.isEmpty ? "C'est fait." : clean,
    match.group(1),
    match.group(2),
  );
}

/// Représente une intention/action détectée dans la réponse ou la demande de l'utilisateur.
/// Utilisé pour afficher les "tâches" dans l'onglet Tâches de l'app.
class OrionTask {
  final String title;
  final String status; // 'en cours', 'terminée', 'échouée'
  final DateTime timestamp;

  OrionTask({required this.title, required this.status, DateTime? timestamp})
      : timestamp = timestamp ?? DateTime.now();
}
