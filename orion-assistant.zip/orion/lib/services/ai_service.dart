import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import '../config/app_config.dart';

/// Gère la communication avec le cerveau IA d'ORION (Groq par défaut,
/// facilement remplaçable par Mistral ou Gemini, voir méthodes plus bas).
class AiService {
  static const _endpointGroq = 'https://api.groq.com/openai/v1/chat/completions';

  Future<String> _getKey() async {
    if (AppConfig.groqApiKey.isNotEmpty) return AppConfig.groqApiKey;
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('groq_api_key') ?? '';
  }

  /// Envoie une question à ORION et retourne la réponse texte complète.
  Future<String> ask(String userMessage, {List<Map<String, String>>? history}) async {
    final key = await _getKey();
    if (key.isEmpty) {
      return "Je n'ai pas encore de clé API. Ajoute ta clé Groq dans les Réglages d'ORION.";
    }

    final messages = [
      {'role': 'system', 'content': AppConfig.orionSystemPrompt},
      ...?history,
      {'role': 'user', 'content': userMessage},
    ];

    try {
      final response = await http.post(
        Uri.parse(_endpointGroq),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $key',
        },
        body: jsonEncode({
          'model': AppConfig.groqModel,
          'messages': messages,
          'temperature': 0.6,
          'max_tokens': 500,
        }),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(utf8.decode(response.bodyBytes));
        return data['choices'][0]['message']['content'] as String;
      } else {
        return "Erreur ORION (${response.statusCode}) : ${response.body}";
      }
    } catch (e) {
      return "Je n'arrive pas à contacter le serveur. Vérifie ta connexion. ($e)";
    }
  }

  /// --- Alternative Mistral (décommente et adapte si tu préfères Mistral) ---
  // static const _endpointMistral = 'https://api.mistral.ai/v1/chat/completions';
  // model: 'mistral-large-latest'

  /// --- Alternative Gemini (décommente et adapte si tu préfères Gemini) ---
  // static const _endpointGemini =
  //   'https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent';
}

/// Représente une intention/action détectée dans la réponse ou la demande de l'utilisateur.
/// Utilisé pour afficher les "tâches" dans l'onglet Tâches de l'app.
class OrionTask {
  final String title;
  final String status; // 'en cours', 'terminée', 'échouée'
  final DateTime timestamp;

  OrionTask({required this.title, required this.status, DateTime? timestamp})
      : timestamp = timestamp ?? DateTime.now();
}
