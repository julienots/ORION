import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import '../config/app_config.dart';

/// Gère la communication avec le cerveau IA d'ORION (Groq par défaut,
/// facilement remplaçable par Mistral ou Gemini, voir méthodes plus bas).
class AiService {
  static const _endpointGroq = 'https://api.groq.com/openai/v1/chat/completions';

  Future<String> _getKey() async {
    if (AppConfig.groqApiKey.isNotEmpty) return AppConfig.groqApiKey;
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('groq_api_key') ?? '';
  }

  /// Envoie une question à ORION et retourne la réponse texte complète.
  Future<String> ask(String userMessage, {List<Map<String, String>>? history}) async {
    final key = await _getKey();
    if (key.isEmpty) {
      return "Je n'ai pas encore de clé API. Ajoute ta clé Groq dans les Réglages d'ORION.";
    }

    final messages = [
      {'role': 'system', 'content': AppConfig.orionSystemPrompt},
      ...?history,
      {'role': 'user', 'content': userMessage},
    ];

    try {
      final response = await http.post(
        Uri.parse(_endpointGroq),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $key',
        },
        body: jsonEncode({
          'model': AppConfig.groqModel,
          'messages': messages,
          'temperature': 0.6,
          'max_tokens': 500,
        }),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(utf8.decode(response.bodyBytes));
        return data['choices'][0]['message']['content'] as String;
      } else {
        return "Erreur ORION (${response.statusCode}) : ${response.body}";
      }
    } catch (e) {
      return "Je n'arrive pas à contacter le serveur. Vérifie ta connexion. ($e)";
    }
  }

  /// --- Alternative Mistral (décommente et adapte si tu préfères Mistral) ---
  // static const _endpointMistral = 'https://api.mistral.ai/v1/chat/completions';
  // model: 'mistral-large-latest'

  /// --- Alternative Gemini (décommente et adapte si tu préfères Gemini) ---
  // static const _endpointGemini =
  //   'https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent';
}

/// Tag technique que le prompt système demande à l'IA d'ajouter quand elle
/// détecte une vraie action à effectuer, ex : "[[ACTION:OPEN_APP:chrome]]".
/// Jamais lu à voix haute : on l'extrait ici avant de parler/afficher.
final RegExp _actionTag = RegExp(r'\[\[ACTION:([A-Z_]+):(.*?)\]\]', dotAll: true);

/// Résultat du découpage d'une réponse d'ORION : le texte à dire/afficher,
/// et l'action éventuelle à exécuter réellement sur le téléphone.
class ParsedResponse {
  final String spokenText;
  final String? actionType;
  final String? actionParam;
  const ParsedResponse(this.spokenText, this.actionType, this.actionParam);
}

ParsedResponse parseOrionResponse(String raw) {
  final match = _actionTag.firstMatch(raw);
  if (match == null) return ParsedResponse(raw.trim(), null, null);
  final clean = raw.replaceAll(_actionTag, '').trim();
  return ParsedResponse(
    clean.isEmpty ? "C'est fait." : clean,
    match.group(1),
    match.group(2),
  );
}

/// Représente une intention/action détectée dans la réponse ou la demande de l'utilisateur.
/// Utilisé pour afficher les "tâches" dans l'onglet Tâches de l'app.
class OrionTask {
  final String title;
  final String status; // 'en cours', 'terminée', 'échouée'
  final DateTime timestamp;

  OrionTask({required this.title, required this.status, DateTime? timestamp})
      : timestamp = timestamp ?? DateTime.now();
}
