import 'package:flutter_background_service/flutter_background_service.dart';
import 'package:flutter_background_service_android/flutter_background_service_android.dart';
import 'wake_word_service.dart';

/// Initialise le service Android "foreground" qui permet à ORION d'écouter
/// le mot de réveil même quand l'application est fermée.
/// Android exige une notification persistante pour tout service qui utilise
/// le micro en arrière-plan (impossible de le rendre 100% invisible, c'est
/// une contrainte du système, pas de l'app).
Future<void> initBackgroundService() async {
  final service = FlutterBackgroundService();

  await service.configure(
    androidConfiguration: AndroidConfiguration(
      onStart: onServiceStart,
      autoStart: true,
      isForegroundMode: true,
      notificationChannelId: 'orion_listening',
      initialNotificationTitle: 'ORION',
      initialNotificationContent: 'En écoute... dites "Orion" pour m\'activer',
      foregroundServiceNotificationId: 888,
      foregroundServiceTypes: [AndroidForegroundType.microphone],
    ),
    iosConfiguration: IosConfiguration(),
  );

  service.startService();
}

@pragma('vm:entry-point')
void onServiceStart(ServiceInstance service) async {
  final wakeWordService = WakeWordService();

  if (service is AndroidServiceInstance) {
    service.setAsForegroundService();
  }

  try {
    await wakeWordService.start(
      onWakeWordDetected: () {
        // Signale à l'UI (si l'app est ouverte) qu'ORION a été réveillé, pour
        // qu'elle lance l'écoute active (voir home_screen.dart).
        service.invoke('wake_word_detected');

        // Si l'app est fermée, Android interdit de la rouvrir toute seule
        // (contrainte système, pas de bug) : on rend au moins ça visible en
        // mettant à jour la notification persistante, pour confirmer que le
        // mot-clé a bien été entendu, et inviter à appuyer dessus pour parler.
        if (service is AndroidServiceInstance) {
          service.setForegroundNotificationInfo(
            title: 'ORION vous a entendu',
            content: 'Appuyez pour continuer la conversation.',
          );
        }
      },
    );
  } catch (e) {
    service.invoke('wake_word_error', {'message': e.toString()});
  }

  service.on('stop_listening').listen((event) async {
    await wakeWordService.stop();
    service.stopSelf();
  });

  // Le premier plan (home_screen.dart) nous prévient quand une conversation
  // démarre/se termine, pour qu'on ne se batte pas avec lui pour le micro
  // (les deux utilisent la même reconnaissance vocale du téléphone).
  service.on('pause_wakeword').listen((event) async {
    await wakeWordService.pause();
  });
  service.on('resume_wakeword').listen((event) async {
    await wakeWordService.resume();
  });
}
