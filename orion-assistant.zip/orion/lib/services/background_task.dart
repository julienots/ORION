import 'dart:async';
import 'package:flutter_background_service/flutter_background_service.dart';
import 'package:flutter_background_service_android/flutter_background_service_android.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;
import 'wake_word_service.dart';
import 'ai_service.dart';
import 'action_service.dart';
import 'system_overlay_service.dart';
import '../config/app_config.dart';

/// Service Android permanent pour ORION.
///
/// Une fois activé, ORION reste actif même si l'interface Flutter est fermée.
/// Le même service gère le mot de réveil, la question qui suit, l'IA, les
/// actions et la réponse vocale. Il n'a donc plus besoin de rouvrir l'app après
/// chaque commande.
Future<void> initBackgroundService() async {
  final service = FlutterBackgroundService();

  await service.configure(
    androidConfiguration: AndroidConfiguration(
      onStart: onServiceStart,
      autoStart: true,
      isForegroundMode: true,
      notificationChannelId: 'orion_listening',
      initialNotificationTitle: 'ORION',
      initialNotificationContent: 'Actif — dites « Orion » pour parler',
      foregroundServiceNotificationId: 888,
      foregroundServiceTypes: [AndroidForegroundType.microphone],
    ),
    iosConfiguration: IosConfiguration(),
  );

  await service.startService();
}

@pragma('vm:entry-point')
void onServiceStart(ServiceInstance service) async {
  final wakeWordService = WakeWordService();
  final commandSpeech = stt.SpeechToText();
  final tts = FlutterTts();
  final ai = AiService();
  final actions = ActionService();

  bool busy = false;
  bool stopped = false;

  Future<void> speak(String text) async {
    if (text.trim().isEmpty) return;
    try {
      await tts.setLanguage('fr-FR');
      await tts.setSpeechRate(0.52);
      await tts.setPitch(0.95);
      await tts.setVolume(1.0);
      await tts.speak(text);
      // Laisse le moteur TTS finir avant de remettre le mot de réveil en route.
      await Future<void>.delayed(const Duration(milliseconds: 250));
    } catch (_) {}
  }

  Future<String?> listenForCommand() async {
    final available = await commandSpeech.initialize(
      onError: (_) {},
    );
    if (!available) return null;

    final completer = Completer<String?>();
    Timer? timeout;
    bool completed = false;

    void finish(String? value) {
      if (completed) return;
      completed = true;
      timeout?.cancel();
      commandSpeech.stop();
      completer.complete(value);
    }

    timeout = Timer(const Duration(seconds: 10), () => finish(null));

    try {
      await commandSpeech.listen(
        localeId: 'fr_FR',
        listenFor: const Duration(seconds: 10),
        pauseFor: const Duration(seconds: 4),
        partialResults: true,
        onResult: (result) {
          if (result.finalResult) finish(result.recognizedWords.trim());
        },
      );
    } catch (_) {
      finish(null);
    }

    return completer.future;
  }

  Future<void> handleWakeWord() async {
    if (busy || stopped) return;
    busy = true;

    try {
      if (service is AndroidServiceInstance) {
        service.setForegroundNotificationInfo(
          title: 'ORION vous écoute',
          content: 'Parlez maintenant…',
        );
      }

      // La fenêtre flottante reste disponible même si l'application principale
      // n'est plus ouverte. Elle indique l'état de la conversation.
      await SystemOverlayService.instance.update(
        '🎙️ Je vous écoute…',
        autoDismiss: false,
      );

      final question = await listenForCommand();
      if (question == null || question.trim().isEmpty) {
        await SystemOverlayService.instance.update(
          'Je n’ai rien entendu.',
          type: OrionOverlayType.info,
          autoDismiss: true,
          duration: const Duration(seconds: 2),
        );
        return;
      }

      // Affiche la demande dans sa propre bulle, puis ajoute les états/résultats
      // sans remplacer la demande. Chaque bulle peut être fermée avec X.
      await SystemOverlayService.instance.show(
        '🗣️ $question',
        type: OrionOverlayType.info,
        autoDismiss: false,
      );

      await SystemOverlayService.instance.show(
        '🤔 ORION réfléchit…',
        type: OrionOverlayType.thinking,
        autoDismiss: true,
        duration: const Duration(seconds: 4),
      );

      final raw = await ai.ask(question);
      final parsed = parseOrionResponse(raw);

      if (parsed.actionType != null) {
        await SystemOverlayService.instance.show(
          '⚡ ${parsed.actionType} ${parsed.actionParam ?? ''}'.trim(),
          type: OrionOverlayType.action,
          autoDismiss: false,
        );
        final result = await actions.run(
          parsed.actionType!,
          parsed.actionParam ?? '',
        );
        await SystemOverlayService.instance.show(
          result.message,
          type: result.success
              ? OrionOverlayType.success
              : OrionOverlayType.error,
          autoDismiss: false,
        );
      } else {
        await SystemOverlayService.instance.show(
          parsed.spokenText,
          type: OrionOverlayType.success,
          autoDismiss: false,
        );
      }

      await speak(parsed.spokenText);
    } finally {
      busy = false;
      if (!stopped) {
        if (service is AndroidServiceInstance) {
          service.setForegroundNotificationInfo(
            title: 'ORION',
            content: 'Actif — dites « Orion » pour parler',
          );
        }
        // IMPORTANT : après chaque réponse, on remet immédiatement l'écoute
        // du mot ORION. L'utilisateur peut donc dire « Orion » puis une autre
        // question sans rouvrir l'application, même après une action.
        await wakeWordService.resume();
      }
    }
  }

  if (service is AndroidServiceInstance) {
    service.setAsForegroundService();
  }

  try {
    await wakeWordService.start(
      onWakeWordDetected: handleWakeWord,
    );
  } catch (e) {
    service.invoke('wake_word_error', {'message': e.toString()});
  }

  service.on('stop_listening').listen((event) async {
    stopped = true;
    await wakeWordService.stop();
    await commandSpeech.stop();
    await tts.stop();
    service.stopSelf();
  });

  // Compatibilité avec l'ancienne interface de l'app. Le service reste
  // maître de l'écoute : ces événements ne sont utilisés que si l'écran
  // principal demande explicitement une pause/relance.
  service.on('pause_wakeword').listen((event) async {
    if (!busy) await wakeWordService.pause();
  });
  service.on('resume_wakeword').listen((event) async {
    if (!busy && !stopped) await wakeWordService.resume();
  });
}
