import 'package:flutter_background_service/flutter_background_service.dart';
import 'package:flutter_background_service_android/flutter_background_service_android.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'wake_word_service.dart';

/// Initialise le service Android "foreground" qui permet à ORION d'écouter
/// le mot de réveil même quand l'application est fermée.
/// Android exige une notification persistante pour tout service qui utilise
/// le micro en arrière-plan (impossible de le rendre 100% invisible, c'est
/// une contrainte du système, pas de l'app).
Future<void> initBackgroundService() async {
  final service = FlutterBackgroundService();

  await service.configure(
    androidConfiguration: AndroidConfiguration(
      onStart: onServiceStart,
      autoStart: true,
      isForegroundMode: true,
      notificationChannelId: 'orion_listening',
      initialNotificationTitle: 'ORION',
      initialNotificationContent: 'En écoute... dites "Orion" pour m\'activer',
      foregroundServiceNotificationId: 888,
      foregroundServiceTypes: [AndroidForegroundType.microphone],
    ),
    iosConfiguration: IosConfiguration(),
  );

  service.startService();
}

@pragma('vm:entry-point')
void onServiceStart(ServiceInstance service) async {
  final prefs = await SharedPreferences.getInstance();
  final accessKey = prefs.getString('picovoice_access_key') ?? '';
  final wakeWordService = WakeWordService();

  if (service is AndroidServiceInstance) {
    service.setAsForegroundService();
  }

  try {
    await wakeWordService.start(
      accessKey: accessKey,
      onWakeWordDetected: () {
        // Signale à l'UI (si ouverte) qu'ORION a été réveillé,
        // et remonte une notification / ouvre l'app pour lancer l'écoute active.
        service.invoke('wake_word_detected');
      },
    );
  } catch (e) {
    service.invoke('wake_word_error', {'message': e.toString()});
  }

  service.on('stop_listening').listen((event) async {
    await wakeWordService.stop();
    service.stopSelf();
  });
}
