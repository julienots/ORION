import 'package:flutter_tts/flutter_tts.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;

/// Gère l'écoute (Speech-to-Text) et la voix d'ORION (Text-to-Speech).
class VoiceService {
  final stt.SpeechToText _speech = stt.SpeechToText();
  final FlutterTts _tts = FlutterTts();

  bool isListening = false;
  bool isSpeaking = false;

  Future<bool> init() async {
    final available = await _speech.initialize(
      onStatus: (status) => isListening = status == 'listening',
      onError: (error) => isListening = false,
    );

    await _tts.setLanguage('fr-FR');
    await _tts.setSpeechRate(0.52); // débit naturel, ni robotique ni trop rapide
    await _tts.setPitch(0.95); // légèrement grave, ton "JARVIS"
    await _tts.setVolume(1.0);

    // Essaie de sélectionner une voix française de haute qualité si disponible
    // (les voix "Wavenet"/neurales du moteur Google TTS installé sur l'appareil
    // sonnent nettement mieux que la voix par défaut).
    final voices = await _tts.getVoices;
    if (voices != null) {
      for (final v in voices) {
        final name = (v['name'] ?? '').toString().toLowerCase();
        final locale = (v['locale'] ?? '').toString().toLowerCase();
        if (locale.contains('fr') && (name.contains('wavenet') || name.contains('neural'))) {
          await _tts.setVoice({'name': v['name'], 'locale': v['locale']});
          break;
        }
      }
    }

    return available;
  }

  Future<void> listenOnce({
    required Function(String text) onResult,
    Duration timeout = const Duration(seconds: 8),
  }) async {
    if (!_speech.isAvailable) await init();
    isListening = true;
    await _speech.listen(
      localeId: 'fr_FR',
      listenFor: timeout,
      onResult: (result) {
        if (result.finalResult) {
          isListening = false;
          onResult(result.recognizedWords);
        }
      },
    );
  }

  Future<void> stopListening() async {
    await _speech.stop();
    isListening = false;
  }

  Future<void> speak(String text, {Function()? onStart, Function()? onDone}) async {
    isSpeaking = true;
    _tts.setStartHandler(() {
      isSpeaking = true;
      onStart?.call();
    });
    _tts.setCompletionHandler(() {
      isSpeaking = false;
      onDone?.call();
    });
    await _tts.speak(text);
  }

  Future<void> stopSpeaking() async {
    await _tts.stop();
    isSpeaking = false;
  }
}
