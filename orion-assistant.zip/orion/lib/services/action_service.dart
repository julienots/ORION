import 'package:url_launcher/url_launcher.dart';
import 'package:android_intent_plus/android_intent.dart';
import 'package:android_intent_plus/flag.dart';

/// Résultat de l'exécution d'une action demandée à ORION.
class ActionResult {
  final bool success;
  final String message;
  const ActionResult(this.success, this.message);
}

/// C'est ici que se passe ce qui manquait entièrement avant : exécuter pour
/// de vrai les actions détectées dans la réponse de l'IA (voir le tag
/// [[ACTION:TYPE:PARAM]] généré grâce au prompt système dans app_config.dart),
/// au lieu de se contenter d'en parler à voix haute.
class ActionService {
  // Alias courants -> package Android. Liste volontairement limitée aux apps
  // les plus demandées ; facile à compléter au besoin.
  static const Map<String, String> _packages = {
    'chrome': 'com.android.chrome',
    'whatsapp': 'com.whatsapp',
    'gmail': 'com.google.android.gm',
    'maps': 'com.google.android.apps.maps',
    'google maps': 'com.google.android.apps.maps',
    'youtube': 'com.google.android.youtube',
    'spotify': 'com.spotify.music',
    'instagram': 'com.instagram.android',
    'facebook': 'com.facebook.katana',
    'play store': 'com.android.vending',
    'playstore': 'com.android.vending',
    'photos': 'com.google.android.apps.photos',
    'messages': 'com.google.android.apps.messaging',
  };

  Future<ActionResult> run(String type, String param) async {
    final p = param.trim();
    try {
      switch (type) {
        case 'OPEN_APP':
          return await _openApp(p);
        case 'CALL':
          return await _call(p);
        case 'SEARCH':
          return await _openUrl(
              'https://www.google.com/search?q=${Uri.encodeQueryComponent(p)}');
        case 'OPEN_URL':
          final url = p.startsWith('http') ? p : 'https://$p';
          return await _openUrl(url);
        default:
          return ActionResult(false, 'Action inconnue : $type');
      }
    } catch (e) {
      return ActionResult(false, "Je n'ai pas réussi à faire ça : $e");
    }
  }

  Future<ActionResult> _openApp(String name) async {
    final key = name.toLowerCase().trim();

    if (key.contains('parametre') || key.contains('réglage') || key.contains('reglage')) {
      await AndroidIntent(action: 'android.settings.SETTINGS').launch();
      return const ActionResult(true, 'Réglages ouverts.');
    }
    if (key.contains('appareil photo') || key.contains('caméra') || key.contains('camera')) {
      await AndroidIntent(action: 'android.media.action.IMAGE_CAPTURE').launch();
      return const ActionResult(true, 'Appareil photo ouvert.');
    }

    final package = _packages[key];
    if (package == null) {
      // App inconnue : on ne reste pas silencieux, on propose la fiche Play Store.
      return _openUrl(
          'https://play.google.com/store/search?q=${Uri.encodeQueryComponent(name)}');
    }

    final intent = AndroidIntent(
      action: 'android.intent.action.MAIN',
      category: 'android.intent.category.LAUNCHER',
      package: package,
      flags: <int>[Flag.FLAG_ACTIVITY_NEW_TASK],
    );
    await intent.launch();
    return ActionResult(true, '$name ouvert.');
  }

  Future<ActionResult> _call(String number) async {
    final clean = number.replaceAll(RegExp(r'[^0-9+]'), '');
    if (clean.isEmpty) return const ActionResult(false, 'Numéro invalide.');
    // ACTION_DIAL (pas ACTION_CALL) : ouvre le composeur pré-rempli sans
    // exiger la permission d'appel direct, plus sûr par défaut.
    await AndroidIntent(action: 'android.intent.action.DIAL', data: 'tel:$clean').launch();
    return const ActionResult(true, 'Composeur ouvert.');
  }

  Future<ActionResult> _openUrl(String url) async {
    final uri = Uri.parse(url);
    final ok = await launchUrl(uri, mode: LaunchMode.externalApplication);
    return ActionResult(ok, ok ? 'Ouvert.' : "Impossible d'ouvrir ça.");
  }
}
