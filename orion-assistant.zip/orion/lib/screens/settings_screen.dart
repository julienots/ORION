import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:flutter_background_service/flutter_background_service.dart';
import '../services/background_task.dart';
import '../services/system_overlay_service.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});
  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final _groqCtrl = TextEditingController();
  final _mistralCtrl = TextEditingController();
  final _geminiCtrl = TextEditingController();
  bool _backgroundEnabled = false;
  bool _overlayGranted = false;
  String _provider = 'groq';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    _groqCtrl.text = prefs.getString('groq_api_key') ?? '';
    _mistralCtrl.text = prefs.getString('mistral_api_key') ?? '';
    _geminiCtrl.text = prefs.getString('gemini_api_key') ?? '';
    _provider = prefs.getString('ai_provider') ?? 'groq';
    _backgroundEnabled = prefs.getBool('background_enabled') ?? false;
    _overlayGranted = await SystemOverlayService.instance.hasPermission();
    setState(() {});
  }

  Future<void> _toggleOverlay(bool value) async {
    if (value) {
      final granted = await SystemOverlayService.instance.requestPermission();
      setState(() => _overlayGranted = granted);
      if (!granted && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Permission refusée : pas de cartes par-dessus les autres apps.')),
        );
      }
    } else {
      // Android ne permet pas de retirer la permission par programme : on
      // renvoie vers ses réglages pour qu'il la désactive lui-même.
      await SystemOverlayService.instance.requestPermission();
      setState(() {});
      _overlayGranted = await SystemOverlayService.instance.hasPermission();
      setState(() {});
    }
  }

  Future<void> _save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('groq_api_key', _groqCtrl.text.trim());
    await prefs.setString('mistral_api_key', _mistralCtrl.text.trim());
    await prefs.setString('gemini_api_key', _geminiCtrl.text.trim());
    await prefs.setString('ai_provider', _provider);
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Réglages sauvegardés.')),
      );
    }
  }

  Future<void> _toggleBackground(bool value) async {
    if (value) {
      final mic = await Permission.microphone.request();
      final notif = await Permission.notification.request();
      if (!mic.isGranted) {
        if (mounted) {
          ScaffoldMessenger.of(context)
              .showSnackBar(const SnackBar(content: Text('Permission micro refusée.')));
        }
        return;
      }
      await initBackgroundService();
    } else {
      FlutterBackgroundService().invoke('stop_listening');
    }
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('background_enabled', value);
    setState(() => _backgroundEnabled = value);
  }

  Widget _keyField(TextEditingController ctrl, String label, String hint) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextField(
        controller: ctrl,
        style: const TextStyle(color: Colors.white),
        decoration: InputDecoration(
          labelText: label,
          labelStyle: const TextStyle(color: Colors.white54),
          helperText: hint,
          helperStyle: const TextStyle(color: Colors.white38, fontSize: 11),
          helperMaxLines: 2,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const Text('Cerveau IA', style: TextStyle(color: Colors.white, fontSize: 18)),
        const SizedBox(height: 8),
        const Text(
          'Si Groq répond "Erreur ORION (403)", c\'est Groq qui bloque ton réseau '
          '(VPN, hébergeur, parfois certains opérateurs mobiles) — pas ta clé. '
          'Choisis Mistral ou Gemini à la place.',
          style: TextStyle(color: Colors.white54, fontSize: 12, height: 1.4),
        ),
        const SizedBox(height: 12),
        SegmentedButton<String>(
          segments: const [
            ButtonSegment(value: 'groq', label: Text('Groq')),
            ButtonSegment(value: 'mistral', label: Text('Mistral')),
            ButtonSegment(value: 'gemini', label: Text('Gemini')),
          ],
          selected: {_provider},
          onSelectionChanged: (s) => setState(() => _provider = s.first),
        ),
        const SizedBox(height: 20),
        const Text('Clés API', style: TextStyle(color: Colors.white, fontSize: 18)),
        const SizedBox(height: 12),
        _keyField(_groqCtrl, 'Clé Groq', 'console.groq.com/keys'),
        _keyField(_mistralCtrl, 'Clé Mistral', 'console.mistral.ai — active le plan "Experiment" (gratuit)'),
        _keyField(_geminiCtrl, 'Clé Gemini', 'aistudio.google.com/apikey — gratuite avec quota journalier'),
        const SizedBox(height: 8),
        ElevatedButton(onPressed: _save, child: const Text('Enregistrer')),
        const Divider(height: 40, color: Colors.white24),
        SwitchListTile(
          value: _backgroundEnabled,
          onChanged: _toggleBackground,
          title: const Text('Écoute "ORION" en arrière-plan',
              style: TextStyle(color: Colors.white)),
          subtitle: const Text(
            'Nécessite une notification persistante (contrainte Android).',
            style: TextStyle(color: Colors.white54),
          ),
        ),
        SwitchListTile(
          value: _overlayGranted,
          onChanged: _toggleOverlay,
          title: const Text('Cartes d\'info par-dessus les autres apps',
              style: TextStyle(color: Colors.white)),
          subtitle: const Text(
            'Affiche ce qu\'ORION fait même quand vous êtes dans une autre app '
            '(façon bulle Messenger). Ouvre l\'écran système Android.',
            style: TextStyle(color: Colors.white54),
          ),
        ),
      ],
    );
  }
}
