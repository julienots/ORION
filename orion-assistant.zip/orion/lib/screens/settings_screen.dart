import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:permission_handler/permission_handler.dart';
import '../services/background_task.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});
  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final _groqCtrl = TextEditingController();
  final _picoCtrl = TextEditingController();
  bool _backgroundEnabled = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    _groqCtrl.text = prefs.getString('groq_api_key') ?? '';
    _picoCtrl.text = prefs.getString('picovoice_access_key') ?? '';
    _backgroundEnabled = prefs.getBool('background_enabled') ?? false;
    setState(() {});
  }

  Future<void> _save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('groq_api_key', _groqCtrl.text.trim());
    await prefs.setString('picovoice_access_key', _picoCtrl.text.trim());
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Réglages sauvegardés.')),
      );
    }
  }

  Future<void> _toggleBackground(bool value) async {
    if (value) {
      final mic = await Permission.microphone.request();
      final notif = await Permission.notification.request();
      if (!mic.isGranted) {
        if (mounted) {
          ScaffoldMessenger.of(context)
              .showSnackBar(const SnackBar(content: Text('Permission micro refusée.')));
        }
        return;
      }
      await initBackgroundService();
    }
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('background_enabled', value);
    setState(() => _backgroundEnabled = value);
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const Text('Clés API', style: TextStyle(color: Colors.white, fontSize: 18)),
        const SizedBox(height: 12),
        TextField(
          controller: _groqCtrl,
          style: const TextStyle(color: Colors.white),
          decoration: const InputDecoration(
            labelText: 'Clé Groq (console.groq.com)',
            labelStyle: TextStyle(color: Colors.white54),
          ),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _picoCtrl,
          style: const TextStyle(color: Colors.white),
          decoration: const InputDecoration(
            labelText: 'Clé Picovoice (console.picovoice.ai)',
            labelStyle: TextStyle(color: Colors.white54),
          ),
        ),
        const SizedBox(height: 16),
        ElevatedButton(onPressed: _save, child: const Text('Enregistrer')),
        const Divider(height: 40, color: Colors.white24),
        SwitchListTile(
          value: _backgroundEnabled,
          onChanged: _toggleBackground,
          title: const Text('Écoute "ORION" en arrière-plan',
              style: TextStyle(color: Colors.white)),
          subtitle: const Text(
            'Nécessite une notification persistante (contrainte Android).',
            style: TextStyle(color: Colors.white54),
          ),
        ),
      ],
    );
  }
}
