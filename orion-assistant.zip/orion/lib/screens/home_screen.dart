import 'package:flutter/material.dart';
import 'package:flutter_background_service/flutter_background_service.dart';
import '../services/voice_service.dart';
import '../services/ai_service.dart';
import '../services/action_service.dart';
import '../widgets/orion_logo.dart';
import 'tasks_screen.dart';
import 'settings_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final VoiceService _voice = VoiceService();
  final AiService _ai = AiService();
  final ActionService _actions = ActionService();
  final List<OrionTask> tasks = [];

  bool _listening = false;
  bool _speaking = false;
  String _statusText = 'Dites "ORION" ou appuyez sur le micro';
  int _navIndex = 0;

  @override
  void initState() {
    super.initState();
    _voice.init();
    _listenForWakeWord();
  }

  /// Écoute l'événement envoyé par le service d'arrière-plan (wake_word_service
  /// + background_task.dart) quand le mot "Orion" est détecté. Sans ce listener,
  /// le mot-clé était bien détecté... mais rien ne se passait jamais à l'écran.
  void _listenForWakeWord() {
    FlutterBackgroundService().on('wake_word_detected').listen((event) {
      if (!mounted || _listening || _speaking) return;
      _startConversation();
    });
  }

  Future<void> _startConversation() async {
    setState(() {
      _listening = true;
      _statusText = "Je vous écoute...";
    });

    await _voice.listenOnce(onResult: (text) async {
      setState(() {
        _listening = false;
        _statusText = 'Vous : "$text"';
      });
      if (text.trim().isEmpty) return;

      final task = OrionTask(title: text, status: 'en cours');
      setState(() => tasks.insert(0, task));

      final raw = await _ai.ask(text);
      final parsed = parseOrionResponse(raw);

      // Si l'IA a demandé une vraie action (ouvrir une app, appeler, chercher...),
      // on l'exécute pour de vrai ici, au lieu de se contenter d'en parler.
      String finalStatus = 'terminée';
      if (parsed.actionType != null) {
        final result = await _actions.run(parsed.actionType!, parsed.actionParam ?? '');
        finalStatus = result.success ? 'terminée' : 'échouée';
      }

      setState(() {
        tasks[0] = OrionTask(title: text, status: finalStatus, timestamp: task.timestamp);
        _statusText = parsed.spokenText;
        _speaking = true;
      });

      await _voice.speak(parsed.spokenText, onDone: () {
        setState(() => _speaking = false);
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    final screens = [
      _buildHome(),
      TasksScreen(tasks: tasks),
      const SettingsScreen(),
    ];

    return Scaffold(
      backgroundColor: const Color(0xFF060B14),
      body: SafeArea(child: screens[_navIndex]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _navIndex,
        onDestinationSelected: (i) => setState(() => _navIndex = i),
        backgroundColor: const Color(0xFF0B1220),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), label: 'ORION'),
          NavigationDestination(icon: Icon(Icons.checklist_outlined), label: 'Tâches'),
          NavigationDestination(icon: Icon(Icons.settings_outlined), label: 'Réglages'),
        ],
      ),
    );
  }

  Widget _buildHome() {
    // SizedBox(width: infinity) force la Column à occuper toute la largeur
    // de l'écran : sans ça, elle ne prend que la largeur de son contenu et
    // se retrouve plaquée à gauche au lieu d'être centrée (le "décalage" que
    // tu vois sur ton écran).
    return SizedBox(
      width: double.infinity,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          const SizedBox(height: 24),
          const Text('O R I O N',
              style: TextStyle(color: Colors.white70, fontSize: 20, letterSpacing: 6)),
          const Spacer(),
          GestureDetector(
            onTap: _startConversation,
            child: OrionLogo(isListening: _listening, isSpeaking: _speaking, size: 240),
          ),
          const Spacer(),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 32),
            child: Text(
              _statusText,
              textAlign: TextAlign.center,
              style: const TextStyle(color: Colors.white70, fontSize: 15, height: 1.4),
            ),
          ),
          const SizedBox(height: 32),
        ],
      ),
    );
  }
}
