import 'package:flutter/material.dart';
import '../services/voice_service.dart';
import '../services/ai_service.dart';
import '../widgets/orion_logo.dart';
import 'tasks_screen.dart';
import 'settings_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final VoiceService _voice = VoiceService();
  final AiService _ai = AiService();
  final List<OrionTask> tasks = [];

  bool _listening = false;
  bool _speaking = false;
  String _statusText = 'Dites "ORION" ou appuyez sur le micro';
  int _navIndex = 0;

  @override
  void initState() {
    super.initState();
    _voice.init();
  }

  Future<void> _startConversation() async {
    setState(() {
      _listening = true;
      _statusText = "Je vous écoute...";
    });

    await _voice.listenOnce(onResult: (text) async {
      setState(() {
        _listening = false;
        _statusText = 'Vous : "$text"';
      });
      if (text.trim().isEmpty) return;

      final task = OrionTask(title: text, status: 'en cours');
      setState(() => tasks.insert(0, task));

      final response = await _ai.ask(text);

      setState(() {
        tasks[0] = OrionTask(title: text, status: 'terminée', timestamp: task.timestamp);
        _statusText = response;
        _speaking = true;
      });

      await _voice.speak(response, onDone: () {
        setState(() => _speaking = false);
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    final screens = [
      _buildHome(),
      TasksScreen(tasks: tasks),
      const SettingsScreen(),
    ];

    return Scaffold(
      backgroundColor: const Color(0xFF060B14),
      body: SafeArea(child: screens[_navIndex]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _navIndex,
        onDestinationSelected: (i) => setState(() => _navIndex = i),
        backgroundColor: const Color(0xFF0B1220),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), label: 'ORION'),
          NavigationDestination(icon: Icon(Icons.checklist_outlined), label: 'Tâches'),
          NavigationDestination(icon: Icon(Icons.settings_outlined), label: 'Réglages'),
        ],
      ),
    );
  }

  Widget _buildHome() {
    return Column(
      children: [
        const SizedBox(height: 24),
        const Text('O R I O N',
            style: TextStyle(color: Colors.white70, fontSize: 20, letterSpacing: 6)),
        const Spacer(),
        GestureDetector(
          onTap: _startConversation,
          child: OrionLogo(isListening: _listening, isSpeaking: _speaking, size: 240),
        ),
        const Spacer(),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 32),
          child: Text(
            _statusText,
            textAlign: TextAlign.center,
            style: const TextStyle(color: Colors.white70, fontSize: 15, height: 1.4),
          ),
        ),
        const SizedBox(height: 32),
      ],
    );
  }
}
