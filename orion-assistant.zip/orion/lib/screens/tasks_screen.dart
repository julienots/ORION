import 'package:flutter/material.dart';
import '../services/ai_service.dart';

/// Affiche l'historique des actions/tâches qu'ORION a exécutées ou est en
/// train d'exécuter (recherche, ouverture d'appli, note, etc.).
class TasksScreen extends StatelessWidget {
  final List<OrionTask> tasks;
  const TasksScreen({super.key, required this.tasks});

  Color _statusColor(String status) {
    switch (status) {
      case 'terminée':
        return Colors.greenAccent;
      case 'échouée':
        return Colors.redAccent;
      default:
        return Colors.amberAccent;
    }
  }

  @override
  Widget build(BuildContext context) {
    if (tasks.isEmpty) {
      return const Center(
        child: Text('Aucune tâche pour le moment.', style: TextStyle(color: Colors.white54)),
      );
    }
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: tasks.length,
      itemBuilder: (context, i) {
        final t = tasks[i];
        return Card(
          color: const Color(0xFF0F1826),
          margin: const EdgeInsets.only(bottom: 10),
          child: ListTile(
            leading: Icon(Icons.bolt, color: _statusColor(t.status)),
            title: Text(t.title, style: const TextStyle(color: Colors.white)),
            subtitle: Text(
              '${t.status} · ${t.timestamp.hour.toString().padLeft(2, '0')}:${t.timestamp.minute.toString().padLeft(2, '0')}',
              style: const TextStyle(color: Colors.white54, fontSize: 12),
            ),
          ),
        );
      },
    );
  }
}
