import 'dart:math';
import 'package:flutter/material.dart';

/// Logo "arc-réacteur" animé d'ORION.
/// - Tourne lentement en permanence (effet 3D via mise à l'échelle des anneaux)
/// - Pulse et s'accélère quand ORION parle (isSpeaking = true)
/// - Change de couleur quand il écoute (isListening = true)
class OrionLogo extends StatefulWidget {
  final bool isSpeaking;
  final bool isListening;
  final double size;

  const OrionLogo({
    super.key,
    this.isSpeaking = false,
    this.isListening = false,
    this.size = 220,
  });

  @override
  State<OrionLogo> createState() => _OrionLogoState();
}

class _OrionLogoState extends State<OrionLogo> with TickerProviderStateMixin {
  late final AnimationController _rotationCtrl;
  late final AnimationController _pulseCtrl;

  @override
  void initState() {
    super.initState();
    _rotationCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 8))
      ..repeat();
    _pulseCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 900))
      ..repeat(reverse: true);
  }

  @override
  void dispose() {
    _rotationCtrl.dispose();
    _pulseCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final color = widget.isListening
        ? const Color(0xFF00E5FF)
        : widget.isSpeaking
            ? const Color(0xFF00FFC2)
            : const Color(0xFF2979FF);

    return AnimatedBuilder(
      animation: Listenable.merge([_rotationCtrl, _pulseCtrl]),
      builder: (context, _) {
        final speed = widget.isSpeaking ? 3.0 : 1.0;
        final pulse = widget.isSpeaking ? (0.9 + _pulseCtrl.value * 0.25) : 1.0;

        return SizedBox(
          width: widget.size,
          height: widget.size,
          child: CustomPaint(
            painter: _OrionPainter(
              rotation: _rotationCtrl.value * 2 * pi * speed,
              pulse: pulse,
              color: color,
              active: widget.isSpeaking || widget.isListening,
            ),
          ),
        );
      },
    );
  }
}

class _OrionPainter extends CustomPainter {
  final double rotation;
  final double pulse;
  final Color color;
  final bool active;

  _OrionPainter({
    required this.rotation,
    required this.pulse,
    required this.color,
    required this.active,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final center = size.center(Offset.zero);
    final baseRadius = size.width / 2;

    // Halo lumineux (donne l'effet "énergie 3D")
    final glowPaint = Paint()
      ..color = color.withOpacity(0.35)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 30);
    canvas.drawCircle(center, baseRadius * 0.55 * pulse, glowPaint);

    // 3 anneaux concentriques, chacun tourne à une vitesse/angle différent
    // et est "aplati" différemment pour simuler la 3D (perspective ellipse).
    for (int i = 0; i < 3; i++) {
      final radius = baseRadius * (0.9 - i * 0.22) * pulse;
      final ringPaint = Paint()
        ..color = color.withOpacity(active ? 0.9 - i * 0.15 : 0.55 - i * 0.1)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 3.5 - i * 0.6
        ..strokeCap = StrokeCap.round;

      canvas.save();
      canvas.translate(center.dx, center.dy);
      canvas.rotate(rotation * (i.isEven ? 1 : -1) * (0.6 + i * 0.3));
      // "Perspective" : on écrase verticalement l'ellipse pour un effet 3D
      final rect = Rect.fromCenter(
        center: Offset.zero,
        width: radius * 2,
        height: radius * 2 * (0.55 + 0.15 * sin(rotation + i)),
      );
      canvas.drawArc(rect, 0, pi * 1.5, false, ringPaint);
      canvas.restore();
    }

    // Noyau central
    final corePaint = Paint()
      ..shader = RadialGradient(
        colors: [Colors.white, color],
      ).createShader(Rect.fromCircle(center: center, radius: baseRadius * 0.18 * pulse));
    canvas.drawCircle(center, baseRadius * 0.18 * pulse, corePaint);
  }

  @override
  bool shouldRepaint(covariant _OrionPainter oldDelegate) => true;
}
