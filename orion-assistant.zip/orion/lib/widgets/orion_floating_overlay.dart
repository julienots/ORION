import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_overlay_window/flutter_overlay_window.dart';

/// Contenu de la fenêtre flottante système (affichée par-dessus les autres
/// apps). Tourne dans son propre moteur Flutter (voir `overlayMain()` dans
/// main.dart) : il ne fait qu'afficher ce que SystemOverlayService (côté app
/// principale) lui envoie via shareData, et le prévient par le même canal
/// quand l'utilisateur ferme une carte lui-même (croix ou glissé).
class OrionFloatingOverlay extends StatefulWidget {
  const OrionFloatingOverlay({super.key});
  @override
  State<OrionFloatingOverlay> createState() => _OrionFloatingOverlayState();
}

class _OrionFloatingOverlayState extends State<OrionFloatingOverlay> {
  List<Map<String, dynamic>> _notices = [];
  StreamSubscription? _sub;

  @override
  void initState() {
    super.initState();
    _sub = FlutterOverlayWindow.overlayListener.listen((event) {
      try {
        final data = event is String ? jsonDecode(event) : event;
        if (data is Map && data['notices'] is List) {
          setState(() {
            _notices = (data['notices'] as List)
                .map((e) => Map<String, dynamic>.from(e as Map))
                .toList();
          });
        }
      } catch (_) {
        // message inattendu : on l'ignore plutôt que de planter la fenêtre.
      }
    });
  }

  @override
  void dispose() {
    _sub?.cancel();
    super.dispose();
  }

  void _dismiss(int id) {
    FlutterOverlayWindow.shareData(jsonEncode({'action': 'dismiss', 'id': id}));
    setState(() => _notices.removeWhere((n) => n['id'] == id));
  }

  IconData _iconFor(String type) {
    switch (type) {
      case 'thinking':
        return Icons.hourglass_top_rounded;
      case 'action':
        return Icons.bolt_rounded;
      case 'success':
        return Icons.check_circle_rounded;
      case 'error':
        return Icons.error_rounded;
      default:
        return Icons.mic_rounded;
    }
  }

  Color _colorFor(String type) {
    switch (type) {
      case 'success':
        return const Color(0xFF2ED47A);
      case 'error':
        return const Color(0xFFFF5A5F);
      case 'action':
        return const Color(0xFF2979FF);
      case 'thinking':
        return const Color(0xFFFFC24B);
      default:
        return const Color(0xFF2979FF);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: _notices.map((n) {
              final id = n['id'] as int;
              final type = (n['type'] ?? 'info').toString();
              final accent = _colorFor(type);
              return Dismissible(
                key: ValueKey(id),
                direction: DismissDirection.horizontal,
                onDismissed: (_) => _dismiss(id),
                child: Container(
                  margin: const EdgeInsets.only(bottom: 8),
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                  decoration: BoxDecoration(
                    color: const Color(0xFF0B1220),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: accent.withOpacity(0.5)),
                    boxShadow: [
                      BoxShadow(color: Colors.black.withOpacity(0.4), blurRadius: 12, offset: const Offset(0, 4)),
                    ],
                  ),
                  child: Row(
                    children: [
                      Icon(_iconFor(type), color: accent, size: 20),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          (n['message'] ?? '').toString(),
                          style: const TextStyle(color: Colors.white, fontSize: 13.5, height: 1.3),
                        ),
                      ),
                      const SizedBox(width: 6),
                      GestureDetector(
                        onTap: () => _dismiss(id),
                        child: const Icon(Icons.close_rounded, color: Colors.white38, size: 18),
                      ),
                    ],
                  ),
                ),
              );
            }).toList(),
          ),
        ),
      ),
    );
  }
}
