import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_overlay_window/flutter_overlay_window.dart';

/// Bulles ORION affichées par-dessus n'importe quelle autre application.
/// Chaque bulle possède sa propre croix de fermeture et peut être balayée.
class OrionFloatingOverlay extends StatefulWidget {
  const OrionFloatingOverlay({super.key});
  @override
  State<OrionFloatingOverlay> createState() => _OrionFloatingOverlayState();
}

class _OrionFloatingOverlayState extends State<OrionFloatingOverlay> {
  List<Map<String, dynamic>> _notices = [];
  StreamSubscription? _sub;

  @override
  void initState() {
    super.initState();
    _sub = FlutterOverlayWindow.overlayListener.listen((event) {
      try {
        final data = event is String ? jsonDecode(event) : event;
        if (data is Map && data['notices'] is List && mounted) {
          setState(() {
            _notices = (data['notices'] as List)
                .map((e) => Map<String, dynamic>.from(e as Map))
                .toList();
          });
        }
      } catch (_) {}
    });
  }

  @override
  void dispose() {
    _sub?.cancel();
    super.dispose();
  }

  void _dismiss(int id) {
    FlutterOverlayWindow.shareData(jsonEncode({'action': 'dismiss', 'id': id}));
    if (mounted) {
      setState(() => _notices.removeWhere((n) => n['id'] == id));
    }
  }

  IconData _iconFor(String type) {
    switch (type) {
      case 'thinking': return Icons.psychology_rounded;
      case 'action': return Icons.bolt_rounded;
      case 'success': return Icons.check_circle_rounded;
      case 'error': return Icons.error_rounded;
      default: return Icons.smart_toy_rounded;
    }
  }

  Color _colorFor(String type) {
    switch (type) {
      case 'success': return const Color(0xFF35E58B);
      case 'error': return const Color(0xFFFF5A6A);
      case 'action': return const Color(0xFF4D8DFF);
      case 'thinking': return const Color(0xFFFFC857);
      default: return const Color(0xFF65A0FF);
    }
  }

  String _labelFor(String type) {
    switch (type) {
      case 'thinking': return 'ORION réfléchit';
      case 'action': return 'Action en cours';
      case 'success': return 'ORION';
      case 'error': return 'Problème';
      default: return 'ORION';
    }
  }

  Widget _bubble(Map<String, dynamic> n) {
    final id = n['id'] as int;
    final type = (n['type'] ?? 'info').toString();
    final accent = _colorFor(type);
    final message = (n['message'] ?? '').toString();

    return Dismissible(
      key: ValueKey(id),
      direction: DismissDirection.horizontal,
      onDismissed: (_) => _dismiss(id),
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        decoration: BoxDecoration(
          color: const Color(0xFF101827).withOpacity(0.98),
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: accent.withOpacity(0.48), width: 1.2),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.42),
              blurRadius: 18,
              offset: const Offset(0, 7),
            ),
          ],
        ),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(12, 11, 9, 12),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 38,
                height: 38,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: accent.withOpacity(0.14),
                  border: Border.all(color: accent.withOpacity(0.38)),
                ),
                child: Icon(_iconFor(type), color: accent, size: 20),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      _labelFor(type),
                      style: TextStyle(
                        color: accent,
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 0.3,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      message,
                      maxLines: 8,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 14,
                        height: 1.32,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 5),
              Material(
                color: Colors.transparent,
                child: InkWell(
                  borderRadius: BorderRadius.circular(18),
                  onTap: () => _dismiss(id),
                  child: const Padding(
                    padding: EdgeInsets.all(5),
                    child: Icon(Icons.close_rounded, color: Colors.white70, size: 20),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: SafeArea(
        child: Align(
          alignment: Alignment.topRight,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(8, 8, 8, 8),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.end,
              children: _notices.map(_bubble).toList(),
            ),
          ),
        ),
      ),
    );
  }
}
