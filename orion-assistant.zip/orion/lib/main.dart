import 'package:flutter/material.dart';
import 'screens/home_screen.dart';
import 'widgets/orion_floating_overlay.dart';

void main() {
  runApp(const OrionApp());
}

/// Point d'entrée de la fenêtre flottante système : tourne dans un moteur
/// Flutter séparé, lancé par flutter_overlay_window quand ORION a une info à
/// montrer par-dessus les autres apps (voir SystemOverlayService).
@pragma('vm:entry-point')
void overlayMain() {
  runApp(const MaterialApp(
    debugShowCheckedModeBanner: false,
    home: OrionFloatingOverlay(),
  ));
}

class OrionApp extends StatelessWidget {
  const OrionApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'ORION',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF060B14),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF2979FF),
          brightness: Brightness.dark,
        ),
        useMaterial3: true,
      ),
      home: const HomeScreen(),
    );
  }
}
