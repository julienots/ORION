/// Configuration centrale d'ORION.
/// ⚠️ Ne mets JAMAIS de vraies clés API en dur ici si le repo est public.
/// Utilise plutôt --dart-define au moment du build (voir README + workflow GitHub Actions),
/// ou saisis-les dans l'écran Réglages de l'app (elles sont alors stockées via SharedPreferences).
class AppConfig {
  // Clé Groq (https://console.groq.com/keys) - gratuite, très rapide (LPU)
  // ⚠️ Bloquée par endroits : Groq refuse certaines IP (VPN, hébergeurs,
  // parfois des IP mobiles selon pays) avec une erreur 403 "Access denied".
  // Si ça t'arrive, choisis Mistral ou Gemini dans Réglages à la place.
  static const String groqApiKey = String.fromEnvironment(
    'GROQ_API_KEY',
    defaultValue: '',
  );

  // Modèle Groq utilisé (rapide + bonne qualité)
  static const String groqModel = 'llama-3.3-70b-versatile';

  // Clé Mistral (https://console.mistral.ai/) - active le plan "Experiment"
  // (gratuit) sur La Plateforme pour avoir une clé utilisable sans payer.
  static const String mistralApiKey = String.fromEnvironment(
    'MISTRAL_API_KEY',
    defaultValue: '',
  );
  static const String mistralModel = 'mistral-small-latest';

  // Clé Gemini (https://aistudio.google.com/apikey) - gratuite avec quota
  // journalier. "gemini-flash-latest" pointe toujours vers le Flash le plus
  // récent, pas besoin de mettre à jour le nom du modèle à la main.
  static const String geminiApiKey = String.fromEnvironment(
    'GEMINI_API_KEY',
    defaultValue: '',
  );
  static const String geminiModel = 'gemini-flash-latest';

  // Mot de réveil détecté via la reconnaissance vocale du téléphone (voir
  // wake_word_service.dart) — pas besoin de compte ni de clé pour ça.
  static const String wakeWord = 'orion';

  static const String orionSystemPrompt = '''
Tu es ORION, un assistant IA vocal embarqué sur smartphone, inspiré de JARVIS.
Réponds toujours en français, de façon concise, directe et naturelle à l'oral
(pas de listes à puces, pas de markdown, des phrases courtes car ta réponse sera lue à voix haute).

Si, et seulement si, l'utilisateur te demande une action réelle sur le téléphone,
termine ta réponse par une ligne technique EXACTEMENT sous cette forme (elle ne
sera jamais lue à voix haute ni affichée : elle sert uniquement à déclencher l'action) :
[[ACTION:TYPE:PARAMÈTRE]]

Types disponibles :
- OPEN_APP:nom  → ouvrir une application (ex: chrome, whatsapp, gmail, maps,
  youtube, spotify, instagram, facebook, play store, parametres, appareil photo)
- CALL:numéro   → ouvrir le composeur avec ce numéro déjà rempli
- SEARCH:requête → lancer une recherche web
- OPEN_URL:url  → ouvrir une page précise (doit commencer par http)

Exemple, si l'utilisateur dit "ouvre Chrome" :
D'accord, j'ouvre Chrome.
[[ACTION:OPEN_APP:chrome]]

Si la demande n'implique aucune action réelle sur le téléphone, ne mets jamais
de ligne [[ACTION...]] et réponds simplement par la conversation normale.
''';
}
