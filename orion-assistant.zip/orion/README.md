# ORION — Assistant IA vocal (base de projet)

Base Flutter fonctionnelle d'un assistant type JARVIS : mot de réveil "ORION",
logo animé, IA via Groq (Llama 3.3), voix française, historique des tâches.

## ⚠️ À lire avant de te lancer (limites réelles, pas de "magie")

- **"Illimité"** : aucune API IA (Groq, Mistral, Gemini) n'est vraiment
  illimitée. Groq a un tier gratuit très généreux et rapide (LPU = réponses
  quasi instantanées), largement suffisant pour un usage perso quotidien —
  mais il y a un quota. Si tu veux du volume très élevé, il faudra un plan payant.
- **Réveil vocal app fermée** : Android 12+ interdit qu'une app écoute le
  micro en tâche de fond sans notification visible en permanence. C'est géré
  ici (foreground service), mais tu ne pourras jamais rendre ça invisible —
  c'est une contrainte du système, pas de l'app. Pense aussi à désactiver
  l'optimisation de batterie pour ORION sinon Android tue le service.
- **Mot-clé "ORION" personnalisé** : nécessite d'entraîner un modèle sur
  Picovoice Console (gratuit, 2 minutes) — voir étape 2 ci-dessous.

## Étapes de configuration

### 1. Clé Groq (le cerveau d'ORION)
1. Va sur https://console.groq.com/keys
2. Crée une clé API gratuite
3. Ajoute-la dans Réglages de l'app une fois installée, OU en secret GitHub (voir plus bas)

### 2. Mot de réveil "ORION" (Picovoice)
1. Crée un compte gratuit sur https://console.picovoice.ai/
2. Section **Porcupine** → "Create Keyword" → tape `Orion` → plateforme **Android**
3. Télécharge le fichier `.ppn` généré
4. Renomme-le `orion_android.ppn` et place-le dans :
   `android/app/src/main/assets/orion_android.ppn`
5. Récupère ta clé "AccessKey" (page d'accueil de la console) → à mettre dans
   Réglages de l'app ou en secret GitHub

### 3. Compiler l'APK via GitHub Actions (déjà configuré)
1. Crée un nouveau repo GitHub et pousse ce dossier dedans :
   ```bash
   git init
   git add .
   git commit -m "ORION - init"
   git branch -M main
   git remote add origin https://github.com/TON_USER/orion-assistant.git
   git push -u origin main
   ```
2. (Optionnel mais recommandé) Ajoute tes clés en secrets :
   Settings du repo → Secrets and variables → Actions → New repository secret
   - `GROQ_API_KEY`
   - `PICOVOICE_ACCESS_KEY`
3. Le workflow `.github/workflows/build_apk.yml` se déclenche automatiquement
   à chaque push sur `main`. Va dans l'onglet **Actions** du repo, ouvre le
   run, télécharge l'artifact **orion-release-apk** → c'est ton APK installable.

### 4. Tester en local (si tu as Flutter installé)
```bash
flutter pub get
flutter run --dart-define=GROQ_API_KEY=ta_cle --dart-define=PICOVOICE_ACCESS_KEY=ta_cle
```

## Ce qui est déjà fait
- Logo 3D animé (anneaux façon arc-réacteur), change de couleur/vitesse selon
  qu'ORION écoute ou parle (`lib/widgets/orion_logo.dart`)
- Appel IA Groq/Llama 3.3 avec prompt système "ORION" en français
- Reconnaissance vocale + synthèse vocale française
- Écran Tâches listant chaque action/demande traitée
- Service arrière-plan + intégration Porcupine pour le réveil "ORION"
- Pipeline CI/CD GitHub Actions → APK prêt à télécharger

## Ce qu'il reste à toi de brancher/affiner
- Les **actions téléphone concrètes** (ouvrir une app précise, envoyer un
  SMS, lancer une recherche web, créer un fichier) : le squelette est prêt
  (`url_launcher`, `android_intent_plus` sont dans les dépendances) mais il
  faut ajouter, dans `ai_service.dart`, une détection d'intention (ex: si la
  réponse contient `ACTION:OPEN_APP:chrome`) puis appeler l'intent correspondant.
- Icône de l'app (`android/app/src/main/res/mipmap-*`)
- Éventuellement remplacer le logo `CustomPainter` par une vraie animation
  3D (Rive/Lottie) si tu veux un rendu encore plus visuel — la structure du
  widget `OrionLogo` est faite pour être facilement remplacée.
